# WorkOrder FSM

## TL;DR
- WorkOrder는 생성(DRAFT) → 팀배정 → 기사배정 → 진행/완료 흐름을 갖습니다.
- 완료 시 서버는 **서명검증 → PDF 생성 → 문자/이메일 발송 → AuditLog 기록**을 자동 수행합니다.

## 본문
1) WorkOrder 상태 다이어그램
상태 정의
• DRAFT: 작업 생성만 됨(임시 저장 포함)
• TEAM_ASSIGNED: 본사가 팀을 배정함
• TECH_ASSIGNED: 팀 관리자가 기사를 배정함
• IN_PROGRESS: 기사가 작업 시작(선택 상태지만 추천)
• COMPLETED: 체크리스트/서명 완료 제출됨 (PDF 생성/발송 트리거)
• CANCELLED: 취소(사유 기록)
전이 규칙
DRAFT
  └─(Admin: 팀 배정)→ TEAM_ASSIGNED
TEAM_ASSIGNED
  └─(TeamManager: 기사 배정)→ TECH_ASSIGNED
TECH_ASSIGNED
  └─(Technician: 작업 시작)→ IN_PROGRESS
IN_PROGRESS
  └─(Technician: 체크리스트 완료 + 서명 필수 + 제출)→ COMPLETED

[취소]
DRAFT / TEAM_ASSIGNED / TECH_ASSIGNED / IN_PROGRESS
  └─(Admin 또는 권한있는 TeamManager)→ CANCELLED
완료(Completed) 시 자동 처리(서버 규칙)
• 서명 존재 여부 검증(필수)
• (선택) 필수 체크리스트 항목 검증
• PDF 생성 → 파일 저장
• 고객 문자/이메일 발송
• AuditLog 기록(성공/실패 포함)

좋아 쭌. 아래는 **Phase 1 – 화면 목록 + 기능 매핑표(페이지 스펙)**이야.
개발자/외주에게 그대로 주면 “무엇을 어떤 화면에서 구현해야 하는지” 바로 이해할 수 있는 형태로 정리했어.
(ERD 초안 기준 테이블명을 괄호로 같이 매핑했음)

2) 화면 목록 + 기능 매핑표
공통(모든 역할)
P-00. 로그인
• 목적: 사용자 인증
• 기능
o 로그인(이메일/비밀번호)
o 비활성 계정 차단
• 데이터
o Read: User
• 검증/정책
o Role 기반으로 메뉴/접근 제어

P-01. 내 정보(프로필)
• 목적: 사용자 기본정보 확인
• 기능
o 이름/전화/이메일 조회(초기엔 수정 제한 가능)
• 데이터
o Read: User

본사 관리자(Admin) 화면
A-01. 관리자 대시보드
• 목적: 오늘 작업/지연/미배정 현황을 한눈에
• 기능
o KPI 카드: 오늘 작업 수, 진행중, 지연, 완료
o 팀별 현황(건수)
o 클릭 시 작업 목록 필터로 이동
• 데이터
o Read: WorkOrder, Team
o Optional Read: AuditLog(최근 이벤트)
• 필터 기본값
o 기간: 오늘(또는 이번 주)

A-02. 작업 목록(WorkOrders)
• 목적: 전체 작업 검색/필터/관리
• 기능
o 리스트(테이블/카드)
o 필터: 상태, 타입(설치/AS), 팀, 지역, 기간, 고객명/현장명
o 정렬: 일정순/생성순/지연순
o “새 작업 생성” 버튼
• 데이터
o Read: WorkOrder + (Customer, Site, Team, User(기사))
• 권한
o Admin: 전체

A-03. 작업 생성(Install/AS 공용)
• 목적: 설치/AS 작업 등록 후 팀 배정까지
• 입력 필드(최소)
o 타입: INSTALL / AS
o 고객 선택(없으면 신규 생성 링크)
o 현장 선택(없으면 신규 생성 링크)
o 일정(방문 예정일/시간)
o 요약/메모
o 우선순위(선택)
o 고객 알림 연락처(휴대폰/이메일) – 선택(하지만 발송 원하면 필수)
• 기능
o 저장(DRAFT)
o 저장+팀배정(TEAM_ASSIGNED)
• 데이터
o Create: WorkOrder
o Read: Customer, Site, Team
o Create: AuditLog(action=CREATE)
• 검증
o 고객/현장 필수
o 타입 필수

A-04. 작업 상세(관리자 뷰)
• 목적: 배정/상태/증빙/문서/발송을 한 곳에서 관리
• 섹션
1. 기본정보: 타입/상태/일정/우선순위
2. 고객/현장: 연락처/주소/메모
3. 배정정보:
• 팀 배정(변경 가능)
• 기사 배정은 “보기만” 또는 정책에 따라 수정 불가(권장)
4. 증빙:
• 체크리스트 결과
• 서명(존재 여부 + 미리보기)
• 사진(전/후)
5. 문서:
• PDF 다운로드 링크
6. 발송:
• 문자/이메일 발송 상태(성공/실패/재발송 버튼)
• 기능
o 팀 배정/변경
o 일정 변경(선택)
o 취소(CANCELLED + 사유)
o PDF 다운로드
o 재발송(문자/이메일)
• 데이터
o Read: WorkOrder, Customer, Site, Team, User, ChecklistItem, WorkOrderAttachment, FileObject, WorkOrderSignature, AuditLog
o Update: WorkOrder(assigned_team_id, schedule, status)
o Create: AuditLog(action=ASSIGN_TEAM / UPDATE_STATUS / SEND_SMS / SEND_EMAIL 등)
• 정책
o COMPLETED 이후 팀/기사 변경은 제한(권장)
o CANCELLED는 Admin만 가능(또는 정책 선택)

A-05. 고객 목록 / 상세
• 목적: 고객/현장 및 이력 조회
• 기능
o 고객 리스트 검색(회사명/담당자)
o 고객 상세: 기본정보 + 현장 리스트 + 최근 작업 이력
• 데이터
o Read: Customer, Site, WorkOrder

A-06. 현장(Site) 상세
• 목적: 현장 기준 설치/AS 히스토리 조회
• 기능
o 현장 정보(주소/담당자)
o 현장 작업 이력(필터: 설치/AS)
o (선택) 설치된 자산(ProductUnit) 리스트
• 데이터
o Read: Site, WorkOrder
o Optional Read: ProductUnit

A-07. 조직/사용자 관리(최소)
• 목적: 팀/기사 계정 관리(초기엔 최소 기능)
• 기능
o 팀 생성/수정/비활성화
o 사용자 생성/수정/비활성화
o 역할 부여(ADMIN / TEAM_MANAGER / TECHNICIAN)
o 사용자-팀 연결
• 데이터
o CRUD: Team, User
o Create: AuditLog(action=UPDATE_USER 등)

A-08. 문서함(검색)
• 목적: PDF/증빙 문서 빠르게 찾기
• 기능
o 검색: 고객명/현장명/기간/타입
o 결과에서 PDF 다운로드
• 데이터
o Read: WorkOrder, WorkOrderAttachment, FileObject, Customer, Site

팀 관리자(Team Manager) 화면
T-01. 팀 대시보드
• 목적: 팀 단위 작업 현황 및 기사 배정 현황
• 기능
o KPI: 오늘 팀 작업, 미배정(기사 없음), 진행중, 완료, 지연
o 기사별 배정 건수
• 데이터
o Read: WorkOrder(where assigned_team_id = 내 team_id), User(role=TECHNICIAN & team_id=내 team_id)

T-02. 팀 작업함(목록)
• 목적: 팀에 떨어진 작업을 기사에게 배정/관리
• 기능
o 리스트 + 필터(상태/기간/고객/현장)
o “기사 미배정” 필터 기본 제공(핵심)
• 데이터
o Read: WorkOrder + Customer + Site

T-03. 작업 상세(팀 관리자 뷰)
• 목적: 기사 배정/재배정 및 진행 확인
• 기능
o 기사 배정(드롭다운)
o 일정 변경(정책 선택)
o 취소(권한 정책에 따라 제한)
o 증빙 조회(체크리스트/서명/사진)
o 발송 상태 확인(재발송은 Admin만 또는 허용)
• 데이터
o Read: WorkOrder, Customer, Site, ChecklistItem, Signature, Attachments
o Update: WorkOrder(assigned_technician_id, status=TECH_ASSIGNED)
o Create: AuditLog(action=ASSIGN_TECH)
• 검증
o TECH_ASSIGNED로 전환 시 기사 필수
o 기사 목록은 “내 팀 소속”만

T-04. 기사 관리(조회 중심)
• 목적: 팀 소속 기사 리스트/상태 확인
• 기능
o 기사 목록/연락처
o 기사별 오늘 배정 건수
• 데이터
o Read: User(where team_id=내 team_id)

기사(Technician) 모바일 웹 화면
M-01. 오늘 작업(리스트)
• 목적: 기사 UX의 핵심 진입점
• 기능
o 카드 리스트: 현장명/주소/시간/연락 버튼
o 상태 배지(배정/진행/완료)
• 데이터
o Read: WorkOrder(where assigned_technician_id = 내 user_id and date in range)

M-02. 작업 상세(기사 수행 화면)
• 목적: 수행/증빙/완료를 한 화면에서 끝내기
• 섹션
1. 현장정보(주소, 전화 버튼, 메모)
2. 작업 정보(타입, 일정, 요약)
3. 체크리스트(필수)
4. 사진 업로드(전/후)
5. 고객 서명(필수)
6. 완료 제출
• 기능
o 작업 시작 버튼(선택: IN_PROGRESS 전환)
o 체크리스트 입력(PASS/FAIL/NA + 메모)
o 사진 업로드(다중)
o 서명 캡처(캔버스)
o 완료 제출
• 데이터
o Read: WorkOrder, ChecklistItem
o Create/Update: ChecklistItem
o Create: FileObject(사진/서명), WorkOrderAttachment, WorkOrderSignature
o Update: WorkOrder(status, completed_at)
o Create: AuditLog(action=UPDATE_STATUS / UPLOAD_FILE / COMPLETE)
• 완료 제출 검증(필수)
o 서명 존재
o 체크리스트 필수 항목 완료
o (정책) 전/후 사진 최소 1장 이상

M-03. 완료 작업(리스트)
• 목적: 기사 본인 이력 확인(최근 N일)
• 기능
o 완료 작업 리스트
o 작업 상세(읽기 전용)
• 데이터
o Read: WorkOrder(where assigned_technician_id=내 user_id and status=COMPLETED)

공통: 자동화/백엔드 처리(화면은 없지만 “기능”으로 명시)
S-01. 완료 후 PDF 생성
• 트리거
o WorkOrder.status = COMPLETED
• 처리
o 템플릿 기반 PDF 생성
o FileObject(PDF) 저장
o WorkOrderAttachment(category=REPORT_PDF) 연결
o AuditLog 기록
S-02. 완료 후 고객 발송(문자/이메일)
• 트리거
o PDF 생성 완료(또는 COMPLETED 직후)
• 처리
o SMS/Email 발송
o 성공/실패 상태 저장(AuditLog + 필요시 별도 NotificationLog 테이블 추가 가능)
o 재발송 요청 시 동일 로직 재실행

3) 페이지-테이블 CRUD 매핑(요약)
• 고객/현장: Customer, Site
• 작업/배정/상태: WorkOrder, Team, User
• 증빙: WorkOrderChecklistItem, WorkOrderSignature, FileObject, WorkOrderAttachment
• 자산(선택): ProductModel, ProductUnit, WorkOrderAsset
• 이력: AuditLog

중요한 UX/운영 정책(문서에 같이 박아두면 좋음)
1. 완료 제출은 “서명 필수”
2. 기사 화면은 “한 화면에서 끝” (탭/메뉴 최소화)
3. 팀관리자는 “기사 미배정 목록”을 기본으로 본다
4. 완료 후 PDF/발송은 자동 처리(기사에게 부담 X)
5. 취소/상태 변경 권한은 최대한 제한(분쟁 방지)

(본문 끝)
===
