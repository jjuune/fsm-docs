# 기사(Technician)

## TL;DR
- 현장에서는 M-02(작업 상세/완료 제출)가 핵심이며, 3~5분 내 완료가 목표입니다.

## M-02 통합 스펙은 별도 문서를 참고하세요.
- 문서: `30-implementation/m02_spec.md`
