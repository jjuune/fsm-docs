# Phase1 문서(v0.1)

## 로컬 실행
```bash
pip install mkdocs-material
mkdocs serve
```

브라우저에서 표시된 주소(보통 http://127.0.0.1:8000 )로 접속하세요.
